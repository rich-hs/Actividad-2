package lista;
import java.util.Scanner;
public class Nombre {
    public static void main(String[] args) {
        Scanner teclas = new Scanner(System.in);
        String name;
        System.out.println("Ingresa nombre del alumno:");
        name = teclas.nextLine();

        int[]a;
        a= new int[5];
        a[0]=7;
        a[1]=9;
        a[2]=8;
        a[3]=4;
        a[4]=5;

        int suma = 0;
        for (int x = 0; x <a.length; x++){
            suma += a[x];
        }

        int promedio = 0;
        promedio = suma / 5;


        System.out.println( "Alumno:" + name);
        System.out.println("Calificaciones:");
        System.out.println("Calificacion 1 es: " + a[0]);
        System.out.println("Calificacion 2 es: " + a[1]);
        System.out.println("Calificacion 3 es: " + a[2]);
        System.out.println("Calificacion 4 es: " + a[3]);
        System.out.println("Calificacion 5 es: " + a[4]);
        System.out.println("El promedio es: " + promedio);


    }









}
